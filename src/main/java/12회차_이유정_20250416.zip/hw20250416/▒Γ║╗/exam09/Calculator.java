package hw20250416.기본.exam09;

public class Calculator {
    double areaRectangle(double a){
        return a*a;
    }
    double areaRectangle(double a, double b) {
        return a * b;
    }
}
