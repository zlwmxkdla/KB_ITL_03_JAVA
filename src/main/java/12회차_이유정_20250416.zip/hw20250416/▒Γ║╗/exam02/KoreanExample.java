package hw20250416.기본.exam02;

public class KoreanExample {
    public static void main(String[] args) {
        Korean k1 = new Korean("박자바","011225-1234567");
        k1.nation="대한민국";

        Korean k2= new Korean("김자바","930525-0654321");
        k2.nation="대한민국";
    }
}
