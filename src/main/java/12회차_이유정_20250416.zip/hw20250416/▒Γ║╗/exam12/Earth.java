package hw20250416.기본.exam12;

public class Earth {
    static final double radius=64000;
    static final double Earth_surface_area;
    static{
        Earth_surface_area = 4*Math.PI*radius*radius;
    }
}
