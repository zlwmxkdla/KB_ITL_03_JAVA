package hw20250416.기본.exam12;

public class EarthExample {
    public static void main(String[] args) {
//상수 읽기
        System.out.println("지구의 반지름: " + Earth.radius + "km");
        System.out.println("지구의 표면적: " + Earth.Earth_surface_area + "km^2");
    }
}
