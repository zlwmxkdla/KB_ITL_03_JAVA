package hw20250423.기본.exam07;

public record Member(String id, String name, int age) {
}
